document.addEventListener('DOMContentLoaded', function() {

  const imgLinks = [
    '/images/tarhun.png',
    '/images/slideTwo.jpg'
];


const imgLinksMob = [
  '/images/tarhunMob.png',
  '/images/slideMob.png'
];


const delay = 5000;
let currentIndex = 0;
let counter = 0;


	function progress() {
    let elem = document.getElementById('progress_bar'),
    width = 1,
    id = setInterval(progressStatus,60);
    function progressStatus(){
      if(width >= 100){
        clearInterval(id);
        elem.style.width = 0;
      } else {
        width++;
        elem.style.width = width + '%';
      }
  }   
} 
  
setInterval(function() {
    document.getElementById('image').src = imgLinks[currentIndex];
    document.getElementById('imageMob').src = imgLinksMob[currentIndex];
    currentIndex++;
    if(currentIndex >= imgLinks.length) {
      currentIndex = 0;
  }
    if(currentIndex >= imgLinksMob.length) {
    currentIndex = 0;
  }
  progress ();
}, delay);


})

